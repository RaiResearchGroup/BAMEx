# BAMEx – the Behavioral Activation Modeling Experimental framework
# 
# Thank you for your interest in BAMEx. This version of BAMEx is not for distribution. 
# Please do not share. If your use of BAMEx results in a publication, please cite as follows: 
# 
# Rai Group. (2017). BAMEx: the Behavioral Adoption Modeling Experimental framework.
# 	 Version 0.1. [Computer Software].
# 
# This project is in a pre-release state. We are actively developing it. If you find 
# something that needs our attention, please send a message to BAMEx.devs@gmail.com. Your 
# feedback and input is extremely valuable. Thank you!
#



#	The general purpose of the init section is to generate the objects (vectors/matrices etc)
#	That the runtime modules use. Note that data processing activities are NOT appropriate here
#	That sort of work should happen in a separate processing stage prior to running the model



SECADAgentInit <- function () {
	print("[Init]          Initializing agents with SECAD module") 
	agents <<- read.csv(as.character(params$SECADagentCSVpath))

	dBugInit(head(agents))
	agents$AdoptDate = as.Date(agents$AdoptDate, "%m/%d/%y") # Make R recognize date format
	dBugInit(head(agents))
	
	
	agents <<- agents[order(agents$agentIndex),]
	rownames(agents) <<- agents$agentIndex
	
	print("[Init]          SECAD Agent initialization loaded agents info")
	dBugInit(head(agents))

	params$num_agents = length(agents$agentIndex)
	print(sprintf("[Init]          SECAD Agent initialization finds %d agents", params$num_agents)) 
	
	agents$initialAdopter <- 0
	agents$initialAdopter[agents$AdoptDate < as.Date("01/01/2008", "%m/%d/%Y")] = 1 #Set initial adopters to those that adopt before 2008
	agents$Adopter <<- agents$initialAdopter
	
	
	print(sprintf("[Init]          SECAD Agent initialization finds %d initial adopters", nrow(agents[agents$initialAdopter == 1,]))) 
	
	dBugInit(agents[agents$initialAdopter == 1,])
	
	
	dBugInit(head(agents))
	
}#------End of SECADAgentInit function




SECADSocNetInit <- function () {
	print("[Init]          Initializing Social Network with SECAD module") 
	
	
	load(file=as.character(params$SECADGeoNei))
	neiDF <<- neiDF[order(neiDF$agentIndex), ]
	rownames(neiDF) <<- neiDF$agentIndex
	print("[Init]          SECAD SocNet initialization loaded geographic neighbor candidates")
	dBugInit(head(neiDF))
	
	print("[Init]          SECAD SocNet initialization checking whether to calculate locals...")
	
	if (!("LocalsAgentIndex" %in% colnames(neiDF)) | params$SECADcalcLocals == TRUE) {
		print("[Init]          SECAD SocNet initialization calculating locals (Get a sandwich, this takes ~90min)")
	
		print("[Init]          SECAD SocNet initialization checking that agent indexes match")
		print(sprintf("[Init]          SECAD SocNet initialization finds %d agents from agent init", length(unique(agents$agentIndex))))
		print(sprintf("[Init]          SECAD SocNet initialization finds %d agents from SocNet", length(unique(neiDF$agentIndex))))
	
		dBugInit("The following is agents that are not in neiDF")
		dBugInit(agents[!(agents$agentIndex %in% neiDF$agentIndex), ])
		dBugInit("The following is neiDFs that are not in agents")
		dBugInit(neiDF[!(neiDF$agentIndex %in% agents$agentIndex), ])
	
		if (length(agents$agentIndex) > length(neiDF$agentIndex) | length(agents$agentIndex) < length(neiDF$agentIndex)) {
			print("[Init]          SECAD SocNet initialization finds agents that don't match - CULLING from both")
			agents <<- agents[agents$agentIndex %in% neiDF$agentIndex, ]
			neiDF <<- neiDF[neiDF$agentIndex %in% agents$agentIndex, ]
			print(sprintf("[Init]          SECAD SocNet initialization finds %d agents from agent init", length(agents$agentIndex)))
			print(sprintf("[Init]          SECAD SocNet initialization finds %d agents from SocNet", length(neiDF$agentIndex)))
			params$num_agents = length(agents$agentIndex)
		} else {
			print("[Init]          SECAD SocNet initialization agent numbers are the same")
		}
	
		print("[Init]          SECAD SocNet initialization applying homophily constraint")
		neiDF$kLocals <- ceiling(neiDF$Geok * 0.05)
	
		dBugInit(proc.time())
	
		neiDF$HomeValue <- agents$HomeValue[fmatch(agents$agentIndex, neiDF$agentIndex)]

		get_NeilistMVal <- function(agentIndList) {
			lapply(agentIndList, function(agInd) agents$HomeValue[fmatch(agInd, agents$agentIndex)])
		}
	
		dBugInit(proc.time())
	
		neiDF$HomeValList_agIndex <- lapply(neiDF$GeoNei, function(agentIndList) unlist(get_NeilistMVal(agentIndList)) )

		zipper_vec <- seq(1:nrow(neiDF))

		dBugInit(proc.time())
	
		neiDF$HomeValListDiff2_agIndex <- sapply(zipper_vec, function (zip) (unlist(neiDF$HomeValList_agIndex[zip]) - neiDF$HomeValue[zip])^2 ) 

		orderhhIndex_Diff2 <- function (zippIndex) { 
			inorder <- order(unlist(neiDF$HomeValListDiff2_agIndex[zippIndex]))
			constrained <- inorder[1:neiDF$kLocals[zippIndex]]
			HCneiList <- unlist(neiDF$GeoNei[zippIndex])[constrained]
			return(HCneiList)
		}
	
		dBugInit(proc.time())
		neiDF$LocalsAgentIndex <- lapply(zipper_vec, function (zip) orderhhIndex_Diff2(zip) ) 
		dBugInit(proc.time())
		dBugInit(head(neiDF))
		
		neiDF$HomeValList_agIndex <- NULL
		neiDF$HomeValListDiff2_agIndex <- NULL
		neiDF$HomeValue <- NULL
		
		print(sprintf("[Init]          SECAD SocNet initialization saving locals - OVERWRITING %s", as.character(params$SECADGeoNei)))
		save(neiDF, file=as.character(params$SECADGeoNei)) 
		
	} else {
		print("[Init]          SECAD SocNet initialization not calculating locals")
		print(sprintf("[Init]          SECAD SocNet initialization locals found for %d agents", nrow(neiDF)))
		if (length(agents$agentIndex) > length(neiDF$agentIndex) | length(agents$agentIndex) < length(neiDF$agentIndex)) {
			print("[Init]          SECAD SocNet initialization finds agents that don't match - CULLING from both")
			
			dBugInit(head(neiDF))
			dBugInit(head(agents))
			
			dBugInit("The following is agents that are not in neiDF")
			dBugInit(agents[!(agents$agentIndex %in% neiDF$agentIndex), ])
			dBugInit("The following is neiDFs that are not in agents")
			dBugInit(neiDF[!(neiDF$agentIndex %in% agents$agentIndex), ])
			
			
			agents <<- agents[agents$agentIndex %in% neiDF$agentIndex, ]
			neiDF <<- neiDF[neiDF$agentIndex %in% agents$agentIndex, ]
			print(sprintf("[Init]          SECAD SocNet initialization finds %d matching agents from agent init", length(agents$agentIndex)))
			print(sprintf("[Init]          SECAD SocNet initialization finds %d matching agents from SocNet", length(neiDF$agentIndex)))
			
			print("[Init]          SECAD SocNet initialization looking for non matching locals")
			if (length(unlist(neiDF$LocalsAgentIndex)[!(unlist(neiDF$LocalsAgentIndex) %in% agents$agentIndex)]) == 0) {
				print("[Init]          SECAD SocNet initialization finds no non-matching locals")
			} else {
				print("[Init]          SECAD SocNet initialization agents don't match - CULLING from Locals")
				print("[Init]          SECAD SocNet initialization agents don't match - ERROR - No code written yet. Quitting")
				q()			
			}	
		}




		dBugInit(sprintf("Minimum number locals: %d", min(neiDF$kLocals)))
		print(sprintf("[Init]          SECAD SocNet initialization SWN random additional wiring with lambda:%f...", params$SECAD_FIT_lambda))
		
		SWNedgeCount = round(params$SECAD_FIT_lambda * neiDF$kLocals)
		
		dBugInit(sprintf("Minimum number SWN rewires: %d", min(SWNedgeCount)))
		dBugInit("But every Agent gets at least one random connection")
		SWNedgeCount[SWNedgeCount == 0] = 1

		dBugInit(sprintf("New minimum number SWN rewires: %d", min(SWNedgeCount)))

		SECADLocals <<- neiDF$LocalsAgentIndex
		SECADnonLocals <<- sapply(SWNedgeCount, sample, x = agents$agentIndex, replace = F )
		
		dBugInit(head(neiDF$LocalsAgentIndex))
		dBugInit(head(SECADnonLocals))
		
		SECADAlter_vec <<- mapply(c, SECADLocals, SECADnonLocals)
		
		dBugInit("Check Atler_vec for agents w/ no locals")
		dBugInit(SECADAlter_vec[neiDF$kLocals == 0])		

		dBugInit("get rid of NA's in Locals part of Alter_vec by replacing with nonLocals only")

		SECADAlter_vec[neiDF$kLocals == 0] <<- SECADnonLocals[neiDF$kLocals == 0]
		
		dBugInit("Check Atler_vec for agents w/ no locals")
		dBugInit(SECADAlter_vec[neiDF$kLocals == 0])
		
		print("[Init]          SECAD SocNet initialization SWN random additional wiring done")
	}
	print("[Init]          SECAD SocNet finished")
	
}#------End of SECADSocNetInit function









#-----------------------------#
# Determine Initialization Routine
#-----------------------------#

initModel <- function () {	
	print("[Init]          Determining Initialization Routine...")
	print(sprintf("[Init]          Agent Initialization Type is: %s", params$AgentInitMod))
	print(sprintf("[Init]          Social Net Initialization Type is: %s", params$SocNetInitMod))
	print(sprintf("[Init]          Runtime Initialization Type is: %s", params$RuntimeInitMod))
	print("[Init]          Initialization Routine determined")
	
	if (params$AgentInitMod == "SECAD") {
		SECADAgentInit()
	}#------End of SECAD Agent init check

	if (params$SocNetInitMod == "SECAD") {
		SECADSocNetInit()
	}#------End of SECAD Social Net init check


}#------End of initModel




