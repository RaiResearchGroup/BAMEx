# BAMEx – the Behavioral Activation Modeling Experimental framework
# 
# Thank you for your interest in BAMEx. This version of BAMEx is not for distribution. 
# Please do not share. If your use of BAMEx results in a publication, please cite as follows: 
# 
# Rai Group. (2017). BAMEx: the Behavioral Adoption Modeling Experimental framework.
# 	 Version 0.1. [Computer Software].
# 
# This project is in a pre-release state. We are actively developing it. If you find 
# something that needs our attention, please send a message to BAMEx.devs@gmail.com. Your 
# feedback and input is extremely valuable. Thank you!
#
# 
#---------------#
# Run Parameters ---- change to run for the models you want to compare
#---------------#
agentCSVpath = "inputs/TOYAgents.csv" 
EmpQuarters = 22
CompareModelNumber <- c(1012224001) 
CompareDescription <- c("Demo1") 
outDir = ("outputs/")




#-------------------------#
# Import Libraries
#-------------------------#

print("[Anls]          Loading Libraries ...")

library(ggplot2)
library(lubridate)

print("[Anls]          ... Libraries Loaded")

#---------------#
# Build empiricals from agents 
#---------------#

print(sprintf("[Anls]          Building empirical comparison from: %s for %d Quarters", agentCSVpath, EmpQuarters))
print("[Anls]          Reading Agent Empiricals")
agents <- read.csv(as.character(agentCSVpath))

print("[Anls]          Calculating Empiricals...")
agents <- agents[agents$AdoptDate != "", ]
agents$AdoptDate = as.Date(agents$AdoptDate, "%m/%d/%y")
agents <- agents[order(agents$AdoptDate), ]
agents$initialAdopter[agents$AdoptDate < as.Date("01/01/2008", "%m/%d/%Y")] = 1 #Set initial adopters to those that adopt before 2008
agents$adopter <- 1

agents$adoptyear <- year(agents$AdoptDate)
agents$adoptmonth <- month(agents$AdoptDate)
agents$adoptquarter <- quarter(agents$AdoptDate)
agents$adoptyearquart <- paste(agents$adoptyear, agents$adoptquarter, sep="")

quartagg <- aggregate(adopter ~ adoptyearquart, data=agents, sum)

sumInitAdopts <- sum(quartagg$adopter[quartagg$adoptyearquart < 20080])

quartagg <- quartagg[quartagg$adoptyearquart > 20080, ]

quartagg <- quartagg[1:EmpQuarters, ]

# sumInitAdopts
# quartagg

Empirics <- data.frame(Quarter = seq(0, EmpQuarters), NewAdopts = c(sumInitAdopts, quartagg$adopter))
Empirics$CumulAdopts <- cumsum(Empirics$NewAdopts)

tmpCumul <- Empirics$CumulAdopts[1:length(Empirics$CumulAdopts)-1]
tmpNewAd <- Empirics$NewAdopts[2:length(Empirics$NewAdopts)]

#tmpCumul
#tmpNewAd

Empirics$EmpGrowRate <- c(0, tmpNewAd/tmpCumul)

Empirics$Model <- "Empirical"
#omit initial conditions (quarter 0)
Empirics <- Empirics[Empirics$Quarter != 0,]


#head(Empirics)
print("[Anls]          ...Empiricals Calculated")


#---------------#
# Get compare models
#---------------#

print("[Anls]          Reading Models to compare")


print(sprintf("[Anls]          Compare Models:%s, Model Descriptions: %s", CompareModelNumber, CompareDescription))

print("[Anls]          Finding Comparison Model Output files")

BatchQuartLog <- data.frame()
for(i in 1:length(CompareModelNumber)) {
	Out_pattern = sprintf("QuarterOuts_BAMEx_Regular_%s_job",CompareModelNumber[i])
	Outfiles = unlist(lapply(Out_pattern, function(x){list.files(path = outDir, pattern =x)}))
	for(j in 1:length(Outfiles)) {
		print(sprintf("[Anls]          Reading Model Output File:%s", Outfiles[j]))
		tmpQuartLog <- read.csv(file = sprintf("%s/%s", outDir, Outfiles[j]))
# ------------  For multiple comparisons
		tmpQuartLog$EconActivated <- NULL
		tmpQuartLog$AttActivated <- NULL
#		print(head(tmpQuartLog))
		BatchQuartLog <<- rbind(BatchQuartLog, tmpQuartLog)
	}	
}

#head(BatchQuartLog)
#BatchQuartLog

#---------------#
# Aggregate compare models
#---------------#

print("[Anls]          Calculating Comparison Model Error...")

Comparison <- BatchQuartLog[BatchQuartLog$Quarter <= EmpQuarters, ]




Comparison$CumulAdoptsSQError <- (Comparison$CumulAdopts - Empirics$CumulAdopts)^2
Comparison$NewAdoptsSQError <- (Comparison$NewAdopts - Empirics$NewAdopts)^2
Comparison$EmpGrowRateSQError <- (Comparison$EmpGrowRate - Empirics$EmpGrowRate)^2

#head(Comparison, n=24)



Errors <- aggregate(CumulAdoptsSQError ~ ModelNum, data = Comparison, mean)
colnames(Errors)[2] = "CumulAdoptsMSE"
Errors$NewAdoptsMSE <- aggregate(NewAdoptsSQError ~ ModelNum, data = Comparison, mean)$NewAdoptsSQError
Errors$EmpGrowRateMSE <- aggregate(EmpGrowRateSQError ~ ModelNum, data = Comparison, mean)$EmpGrowRateSQError

Errors$CumulAdoptsRMSE <- sqrt(Errors$CumulAdoptsMSE)
Errors$NewAdoptsRMSE <- sqrt(Errors$NewAdoptsMSE)
Errors$EmpGrowRateRMSE <- sqrt(Errors$EmpGrowRateMSE)

#head(Errors, n=24)

print("[Anls]          ... Model Error Calculated")
ModelErrorsFile = sprintf("analytics/BAMEx_Errors_%s.csv", paste(CompareModelNumber, collapse="-"))

print(sprintf("[Anls]          Writing Model Errors to %s", ModelErrorsFile))

write.csv(Errors, ModelErrorsFile, row.names=FALSE)


#---------------#
# Make graphic of cumulative installations
#---------------#

BatchQuartLog$Model <- as.factor(BatchQuartLog$ModelNum)
CumAdoptsPlotPathName = sprintf("analytics/graphics/BAMEx_CumAdopts_%s.png", paste(CompareModelNumber, collapse="-"))
#CumAdoptsPlotPathName

png(CumAdoptsPlotPathName, width = 7, height = 7, res = 300, units = 'in', pointsize = 13)	
ggplot(data = BatchQuartLog) +
		geom_point(aes(x = Quarter, y = CumulAdopts, color = Model), size = 1, alpha = .4, position = "jitter")+
		stat_smooth(aes(x = Quarter, y = CumulAdopts, fill = Model, color = Model, group = interaction(Model)), alpha = .7, 
			position = "identity", method = 'gam', formula = y ~ s(x,k=11), show.legend = FALSE, size = 2, level = 0)+	
		geom_point(data = Empirics, aes(x = Quarter, y = CumulAdopts), size = 2) +
		geom_line(data = Empirics, aes(x = Quarter, y = CumulAdopts), color = "darkgoldenrod1", size = 1.5) +
#		ggtitle(sprintf("Cumulative adoptions comparison across %s models.", length(CompareModelNumber))) + 
		ylab("Cumulative Number of PV Systems") +
		scale_color_manual(values=c("#f47470","#455c22","#2075bd"), 
		breaks = CompareModelNumber,
  		labels = CompareDescription, name="Lens") +
		guides(color = guide_legend(override.aes = list(alpha = .9, size = 5), keywidth = 1.5, keyheight = 1.5,
			fill = FALSE, title = "Model", title.theme = element_text(size = 15, face = 'bold', angle = 0), label.theme = element_text(size = 15, angle = 0))) +
		scale_x_continuous("", breaks= seq(0,EmpQuarters), 
			labels=c("","2008","","","","2009","","","","2010","","","",
				"2011","","","","2012","","","","2013","")) +
		theme_bw() + 
		theme(legend.justification=c(0,1), legend.position=c(0,1), panel.grid.minor = element_blank(), 
			panel.grid.major = element_blank(), axis.text = element_text(face = 'bold', size = 15, angle =0),
			axis.title = element_text(face = 'bold', size = 16, angle = 0))

dev.off()




