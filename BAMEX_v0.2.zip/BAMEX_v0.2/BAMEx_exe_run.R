# BAMEx – the Behavioral Activation Modeling Experimental framework
# 
# Thank you for your interest in BAMEx. This version of BAMEx is not for distribution. 
# Please do not share. If your use of BAMEx results in a publication, please cite as follows: 
# 
# Rai Group. (2017). BAMEx: the Behavioral Adoption Modeling Experimental framework.
# 	 Version 0.1. [Computer Software].
#
# This project is in a pre-release state. We are actively developing it. If you find 
# something that needs our attention, please send a message to BAMEx.devs@gmail.com. Your 
# feedback and input is extremely valuable. Thank you!
#
# 
#-------------------------#
#Track Runs/Results
#-------------------------#

#----Model number convention 
#--First digit: 1 for System1, 9 for System2, etc
#--Second/Third digits: Author: 01-Author1, 
#--Fourth digit: number of "batches"
#--5th digit: number of "runs"
#--6th/7th digits:  number of Quarters
#--8th-11th digits: "name" of the run
#-- EG 1012205001 = Two batches of Two Run on system1 with 5 quarters 
#	1012224001 = Two batch of Two Run on PC with 24 quarters - A demo on TOY data

#-------------------------#
# Set working directory if necessary
#-------------------------#

#setwd("<path to working directory>")

#-------------------------#
# Read in Command Line Arguments
#-------------------------#
# Variables passed from solarABMjob bash script

args = commandArgs(TRUE)


#-------------------------#
#Define Model Runtime Parameters
#-------------------------#
params = data.frame(
# - Identification parameters ------------------------------
	job = args[1],
	Model = 1012224001, 									# Used as a outfile designation. Remember to change and log as parameters are altered.
	ModelType = "Regular", 									# Specifies the type/purpose of the model. One of c("Regular")
	batches = 2, 											# Number of batches - batches can have different initial values
	runs = 2,												# Number of runs in a batch - runs share an intialization
	Quarters = 24, 											# Number of ticks in a run. set to quarters 
# - Initialization Modules ---------------------------------
	AgentInitMod = "SECAD",									# Specifies an agent initialization module. One of c("SECAD")
	SocNetInitMod = "SECAD",								# Specifies a social network initialization module. One of c("SECAD")
	SeedAdopters = "Off", 									# Use seeded adopters during initialization?
# -	Runtime Modules ----------------------------------------
	RuntimeInitMod = "SECAD",									# Specifies runtime initialization modules. One of c("SECAD")
	AdoptRunMod = "SECAD", 									# Specifies the adoption determining module. One of c("SECAD")
	ProdInc_budget = "Off", 								# Impose a budget contraint on Production incentives? (NOT IMPLEMENTED)
# - Outputs Modules ----------------------------------------
	RunsOut = "On", 										# Generate summaries for each run? 
	QuartersOut = "On", 									# Generate summary measures by quarter? 
	AdoptionsOut = "On", 									# Generate adoption time/space/threshold output? 
	SocNetOut = "On", 										# Generate Social Network output? 
	ErrorOut = "Off",										# Generate Run-level summary of error? (NOT IMPLEMENTED)
	EndStateOut = "Off", 									# Generate output with adopter final states?
# - ########################################################
# - ###
# - ###			Initialization Module Specific Parameters
# - ###
# - ########################################################
# - SECAD Agent Initialization Module ----------------------
	SECADagentCSVpath = "inputs/TOYAgents.csv", 			# Agent state variables, includes HomeValue	AdoptDate	radMEANft	hhIndex	WGSlat	WGSlong	SIA	U	PBC
# - SECAD Social Network Initialization Module -------------
	SECADGeoNei = "inputs/TOYGeoNeiDF.Rdata",				# Path for neighbors file
	SECADcalcLocals = FALSE,								# Re-calculate locals?
	SECAD_FIT_lambda = 0.4,	 								# Random wiring parameter for SWN

# - ########################################################
# - ###
# - ###			Runtime Module Specific Parameters
# - ###
# - ########################################################
# - SECAD Adoption Runtime Module --------------------------
	SECADEconData = "inputs/TOYSecadEcon.csv", 				# SECAD module Econ data includes: Loess	Tick	SD	Rebate_d_w	Elec_VOC
	SECAD_FIT_steps = 4, 									# number of steps per tick - a step is an opportunity to update SIA
	SECADEconRebateCoefficient = .9556, 					# AE does not give full STC rating credit to panels, but 95%
	SECADEconfedITC = .3,									# Investment Tax Credit
	SECAD_FIT_PBCscaler_a0 = -55,							# Scaling parameters to align PBC with PP
	SECAD_FIT_PBCscaler_a1 = 1.32,							# Scaling parameters to align PBC with PP
	SECADAttitudeModule = "On",								# Run SECAD with Attitude module?
	SECAD_FIT_mu = 0.6, 									# Opinion convergence parameter
	SECAD_FIT_siaThresh = 0.9,								# SIA threshold for attitude activation

# - ########################################################
# - ###
# - ###			Output Module Specific Parameters
# - ###
# - ########################################################

ender = 0)
params$dBug = list(c("Off")) 								# Route debugging output to stdout? Choose from list(c("Outs","Init", "Stage","Run","Step","Substep","Quarter","Off")

# - End of runtime parameters ------------------------------


#-------------------------#
# Interpret Command Line Arguments
#-------------------------#
# Variables passed from solarABMjob bash script

args = commandArgs(TRUE)


if (!is.na(args[2])) {
		print("Additional CMD line args present")
		if (args[2] == "ParamSweep" & (args[3] %in% names(params))) {
				print("[PreRun]     ..........Parameter Sweep argument set")
				params$ModelType = "ParamSweep"
				SweepParameter <<- args[3]
				SweepParameterValue <<- as.numeric(args[4])
				Subrun <- args[5]
				print(sprintf("[PreRun]     Sweeping Parameter: %s; Old Value: %s", SweepParameter, params[,SweepParameter]))
				params[,SweepParameter] =  SweepParameterValue
				params$Model = paste0(params$Model, Subrun) 
				print(sprintf("[PreRun]     Sweeping Parameter: %s; Value set at: %s; SubRun#:%s; Model#:%s", SweepParameter, params[,SweepParameter], Subrun, params$Model))
			} else if (args[2] == "BackFitRun") {
			 	print("[PreRun]     ..........Back Fitting argument set\n")
			 	params$ModelType = "BackfitRun"
			 	Subrun <- args[3]
			 	print(sprintf("[PreRun]     Backfitting SubRun#: %s", Subrun))
			 	params$Model = paste0(params$Model, Subrun) 
			} else {
				print("XXX!!!XXX[PreRun]     	There has been an error	with setting Parameter Sweep Values	or Backfitting XXX!!!XXX")	
				print(sprintf("XXX!!!XXX[PreRun]     	Arg 2: %s; Arg 3: $%s; Arg 4: %s; Arg 5: %s", args[2], args[3], args[4], args[5]))
				q()
		}
	} else {
		cat("No Additional CMD line args present\n")
}

#-------------------------#
# Write out parameters and Set up log outputting
#-------------------------#

print("[PreRun]     Setting up logging...")
write.csv(params[, 1:(ncol(params)-2)], sprintf("runlogs/ParamLog_BAMEx_%s_%s_job%s.csv", params$ModelType, params$Model, params$job), row.names=FALSE)
print(sprintf("[PreRun]     Parameters recorded to ... runlogs/ParamLog_BAMEx_%s_%s_job%s.csv", params$ModelType, params$Model, params$job))
LogFile = sprintf("runlogs/Log_BAMEx_%s_%s_job%s.txt", params$ModelType, params$Model, params$job)
print(sprintf("[PreRun]     Logging to ... %s", LogFile))
sink(LogFile, append=FALSE, type=c("output", "message"))


########################################################
###
###			Load Libraries
###
########################################################
if (params$ModelType == "ParamSweep") {
	print(sprintf("[PreRun]     Sweeping Parameter: %s; Value set at: %s; SubRun#:%s; Model#:%s", SweepParameter, params[,SweepParameter], Subrun, params$Model))
}

print("[Run]     Loading Libraries...")

source("BAMEx_func_support.R")
print("[Run]          Support Library loaded... ")

source("BAMEx_func_init.R")
print("[Run]          Initialization Library loaded... ")

source("BAMEx_func_core.R")
print("[Run]          Core Library loaded... ")

print("[Run]     Libraries Loaded Successfully")

print("[Run]     Determining Output Initialization...")
if (params$RunsOut == "On") {
	RunOuts <<- NULL
}

if (params$QuartersOut == "On") {
	QuarterOuts <<- NULL
}

if (params$AdoptionsOut == "On") {
	AdoptionOuts <<- NULL
}

if (params$EndStateOut == "On") {
	EndStateOuts <<- NULL
}

print("[Run]     Outputs Initialized")

########################################################
###
###			Runtime Orders
###
########################################################




for (b in 1:params$batches){ 
	print(sprintf("[Run]     Initializing batch: %d", b))
	initModel()
	if (params$SocNetOut == "On") {
			if (params$SocNetInitMod == "SECAD") {
				SocNet <- mapply(c, SECADLocals, SECADnonLocals)
				save(SocNet, file=sprintf("outputs/SocNet_BAMEx_%s_%s_b%d_job%s.Rdata", params$ModelType, params$Model, b, params$job) )
		}#------End of SECAD Social Net init check
	}#------End of SocNetOut check
	
	for (r in 1:params$runs){ 
		dBugRun(sprintf("Begining runtime for run: %d", r))
		dBugRun("also, str(q)")
		dBugRun(str(q))
		subModelID <- paste(b,r, sep=":")
		print(sprintf("[Run]     Running run: %d of batch: %d; subModelID: %s", r, b, subModelID))
		print(system.time(runModel(subModelID)))
		
		if (params$RunsOut == "On") {
			if (params$AdoptRunMod == "SECAD") {
				ModelType = params$ModelType
				ModelNum = params$Model
				Runtime = params$AdoptRunMod
				Batch = b
				Run = r
				TotalAdopts = sum(SECADadoptStatus_vec)
				tmpRunOuts <<- cbind(ModelType, ModelNum, Runtime, Batch, Run, subModelID, TotalAdopts)
				RunOuts <<- rbind(RunOuts, tmpRunOuts)
			}#------End of SECAD check

		}#------End of Run out check

		if (params$EndStateOut == "On") {
			if (params$AdoptRunMod == "SECAD") {
				ModelType = params$ModelType
				ModelNum = params$Model
				Runtime = "SECAD"
				Batch = b
				Run = r
				agentID = SECADagentIndex_vec
				WGSlat = agents$WGSlat
				WGSlong = agents$WGSlong
				adopter = SECADadoptStatus_vec
				EconAct = EconActiv_vec
				AttAct = AttActiv_vec
				tmpEndStateOuts <<- cbind(ModelType, ModelNum, Runtime, Batch, Run, subModelID, agentID, WGSlat, WGSlong, adopter, EconAct, AttAct)
				EndStateOuts <<- rbind(EndStateOuts, tmpEndStateOuts)
				dBugOuts(head(EndStateOuts))
			}#------End of SECAD check

		}#------End of EndState out check

		if (params$ErrorOut == "On") {
#			Error output block
		}#------End of Error out check
	}#------End of runs
}#------End of batches

print("time just before a file write event")
print(Sys.time())

if (params$RunsOut == "On") {
	write.csv(RunOuts, file=sprintf("outputs/RunOuts_BAMEx_%s_%s_job%s.csv", params$ModelType, params$Model, params$job), row.names = FALSE )
}

if (params$QuartersOut == "On") {
	write.csv(QuarterOuts, file=sprintf("outputs/QuarterOuts_BAMEx_%s_%s_job%s.csv", params$ModelType, params$Model, params$job), row.names = FALSE )
}

if (params$AdoptionsOut == "On") {
	write.csv(AdoptionOuts, file=sprintf("outputs/AdoptionOuts_BAMEx_%s_%s_job%s.csv", params$ModelType, params$Model, params$job), row.names = FALSE )
}

if (params$EndStateOut == "On") {
	dBugOuts(head(EndStateOuts))
	write.csv(EndStateOuts, file=sprintf("outputs/EndStateOuts_BAMEx_%s_%s_job%s.csv", params$ModelType, params$Model, params$job), row.names = FALSE )
}

print("All done. Goodnight.")
warnings()
q()
