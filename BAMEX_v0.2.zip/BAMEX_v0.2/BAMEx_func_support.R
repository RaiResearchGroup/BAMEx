# BAMEx – the Behavioral Activation Modeling Experimental framework
# 
# Thank you for your interest in BAMEx. This version of BAMEx is not for distribution. 
# Please do not share. If your use of BAMEx results in a publication, please cite as follows: 
#
# Rai Group. (2017). BAMEx: the Behavioral Adoption Modeling Experimental framework.
# 	 Version 0.1. [Computer Software].
#
# This project is in a pre-release state. We are actively developing it. If you find 
# something that needs our attention, please send a message to BAMEx.devs@gmail.com. Your 
# feedback and input is extremely valuable. Thank you!
#
# 


#-----------------------------#
# Load libraries
#-----------------------------#
if (params$SocNetInitMod == "SECAD") {
	library(fastmatch)
}
	


#-----------------------------#
# Debugging verbosity
#-----------------------------#

if ("Init" %in% unlist(params$dBug)) {
	print("[Support] Init Debug on")
	dBugInit = function (message) {print(message)}
} else { dBugInit = function (m) {} } 

if ("Run" %in% unlist(params$dBug)) {
	print("[Support] Run Debug on")
	dBugRun =function (m) {print(m)}
} else { dBugRun = function (m) {} } 

if ("Stage" %in% unlist(params$dBug)) {
	print("[Support] Stage Debug on")
	dBugStage =function (m) {print(m)}
} else { dBugStage = function (m) {} } 

if ("Step" %in% unlist(params$dBug)) {
	print("[Support] Step Debug on")
	dBugStep = function (m) {print(m)}
} else { dBugStep = function (m) {} } 

if ("Substep" %in% unlist(params$dBug)) {
	print("[Support] Substep Debug on")
	dBugSubstep = function (m) {print(m)}
} else { dBugSubstep = function (m) {} } 

if ("Quarter" %in% unlist(params$dBug)) {
	print("[Support] Quarter Debug on")
	dBugQuarter = function (m) {print(m)}
} else { dBugQuarter = function (m) {} } 

if ("Outs" %in% unlist(params$dBug)) {
	print("[Support] Output Debug on")
	dBugOuts = function (m) {print(m)}
} else { dBugOuts = function (m) {} } 
