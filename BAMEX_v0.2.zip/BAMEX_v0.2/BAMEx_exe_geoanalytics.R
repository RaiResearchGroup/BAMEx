# BAMEx – the Behavioral Activation Modeling Experimental framework
# 
# Thank you for your interest in BAMEx. This version of BAMEx is not for distribution. 
# Please do not share. If your use of BAMEx results in a publication, please cite as follows: 
# 
# Rai Group. (2017). BAMEx: the Behavioral Adoption Modeling Experimental framework.
# 	 Version 0.1. [Computer Software].
#
# This project is in a pre-release state. We are actively developing it. If you find 
# something that needs our attention, please send a message to BAMEx.devs@gmail.com. Your 
# feedback and input is extremely valuable. Thank you!
#
# 
#---------------#
# Run Parameters ---- change to run for the models you want to compare
#---------------#
agentCSVpath = "inputs/TOYAgents.csv" 
EmpQuarters = 22
CompareModelNumber <- c(1012224001) 
CompareDescription <- c("Demo1") 
outDir = ("outputs/")




#-------------------------#
# Import Libraries
#-------------------------#

print("[Geos]          Loading Libraries ...")

library(ggplot2)
library(ggmap)

library(lubridate)
library(MASS)
library(scales)
library(reshape2)

print("[Geos]          ... Libraries Loaded")


#---------------#
# Bring in empirical data
#---------------#
print(sprintf("[Geos]          Building empirical comparison from: %s for %d Quarters", agentCSVpath, EmpQuarters))
print("[Geos]          Reading Agent Empiricals")
agents <- read.csv(as.character(agentCSVpath))
agents <- agents[agents$AdoptDate != "", ]
agents$AdoptDate = as.Date(agents$AdoptDate, "%m/%d/%y")
agents <- agents[order(agents$AdoptDate), ]
#head(agents)
#tail(agents)
print(sprintf("Empirical data: Total adopters: %f", nrow(agents)))

#---------------#
# Bring in sim data
#---------------#

print("[Geos]          Reading Model to compare")

print(sprintf("[Geos]          Compare Model:%s, Model Descriptions: %s", CompareModelNumber, CompareDescription))

print("[Geos]          Finding Comparison Model Output files")

BatchAdoptLog <- data.frame()
for(i in 1:length(CompareModelNumber)) {
	Out_pattern = sprintf("AdoptionOuts_BAMEx_Regular_%s_job",CompareModelNumber[i])
	Outfiles = unlist(lapply(Out_pattern, function(x){list.files(path = outDir, pattern =x)}))
	print(sprintf("[Geos]          Preparing to read %d Model Output Files", length(Outfiles)))
	for(j in 1:length(Outfiles)) {
		print(sprintf("[Geos]          Reading Model Output File:%s", Outfiles[j]))
		tmpAdoptLog <- read.csv(file = sprintf("%s/%s", outDir, Outfiles[j]))
		tmpAdoptLog$filenumber <- j
#		print(head(tmpAdoptLog))
		tmpAdoptLog$uniqueRun <- paste(tmpAdoptLog$filenumber, tmpAdoptLog$subModelID, sep="::")
		BatchAdoptLog <<- rbind(BatchAdoptLog, tmpAdoptLog)
	}	
}



#---------------#
# Build empirical geo density map
#---------------#

print(sprintf("[Geos]          Building empirical comparison from: %s for %d Quarters", agentCSVpath, EmpQuarters))
print("[Geos]          Reading Agent Empiricals")
agents <- read.csv(as.character(agentCSVpath))
agents <- agents[agents$AdoptDate != "", ]
agents$AdoptDate = as.Date(agents$AdoptDate, "%m/%d/%y")
agents <- agents[order(agents$AdoptDate), ]
#head(agents)
#tail(agents)
print(sprintf("Empirical data: Total adopters: %f", nrow(agents)))


# min(agents$WGSlong)
# max(agents$WGSlong)
# max(agents$WGSlat)
# min(agents$WGSlat)

print(sprintf("Empirical data: This wide across the Longs: %f", min(agents$WGSlong) - max(agents$WGSlong)))

print(sprintf("Empirical data: This tall up the Lats: %f", max(agents$WGSlat) - min(agents$WGSlat)))

LongRange = c(-98, -97.56)
LatRange = c(30.09, 30.47)

# str(LongRange)
# print("that was str longrange")

# Calculate the 2d density estimate over the common range


N_dens <- 100

BandwidthMultiplier <- 20

LongIncrement <- (max(LongRange)-min(LongRange))/N_dens
LatIncrement <- (max(LatRange)-min(LatRange))/N_dens
# LongIncrement
# LatIncrement


EmpDensMap100 = kde2d(agents$WGSlong, agents$WGSlat, h=c(BandwidthMultiplier*LongIncrement, BandwidthMultiplier*LatIncrement) , lims=c(LongRange, LatRange), n=N_dens)

print(sprintf("Empirical density calculated for a %d square grid", N_dens))


#head(EmpDensMap100)
#length(EmpDensMap100)

# Now melt it to long format
EmpDensMap100.m = melt(EmpDensMap100$z, id.var=rownames(EmpDensMap100))
names(EmpDensMap100.m) = c("Long","Lat","z")

EmpDensMap100.m$adjLong <- (EmpDensMap100.m$Long * LongIncrement) + min(LongRange)
EmpDensMap100.m$adjLat<- (EmpDensMap100.m$Lat * LatIncrement) + min(LatRange)
EmpDensMap100.m$adjz <- rescale(EmpDensMap100.m$z, to = c(0,1))
EmpDensMap100.m$STDadjz <- scale(EmpDensMap100.m$z)

# head(EmpDensMap100.m)
# nrow(EmpDensMap100.m)






#---------------#
# Build sim geo density map
#---------------#



BatchAdoptLog$uniqueRun <- as.factor(BatchAdoptLog$uniqueRun)
# levels(BatchAdoptLog$uniqueRun)
# length(levels(BatchAdoptLog$uniqueRun))
# head(BatchAdoptLog)

SimDensMap100 = kde2d(BatchAdoptLog$AdoptLong, BatchAdoptLog$AdoptLat, h=c(BandwidthMultiplier*LongIncrement, BandwidthMultiplier*LatIncrement), lims=c(LongRange, LatRange), n=N_dens)

print(sprintf("Simulation density calculated for a %d square grid", N_dens))


SimDensMap100.m = melt(SimDensMap100$z, id.var=rownames(SimDensMap100))
names(SimDensMap100.m) = c("Long","Lat","z")

SimDensMap100.m$adjLong <- (SimDensMap100.m$Long * LongIncrement) + min(LongRange)
SimDensMap100.m$adjLat<- (SimDensMap100.m$Lat * LatIncrement) + min(LatRange)
#SimDensMap100.m$z <- SimDensMap100.m$z / length(levels(BatchAdoptLog$uniqueRun))
SimDensMap100.m$adjz <- rescale(SimDensMap100.m$z, to = c(0,1))
SimDensMap100.m$STDadjz <- scale(SimDensMap100.m$z)


print(sprintf("Simulation density range: %f to %f square grid", min(SimDensMap100.m$z), max(SimDensMap100.m$z)))



#---------------#
# Build Difference density map
#---------------#
SimDensMap100.m$Diffz <- SimDensMap100.m$z - EmpDensMap100.m$z
SimDensMap100.m$STDDiffz <- SimDensMap100.m$STDadjz - EmpDensMap100.m$STDadjz 
#---------------#
# Build graphics
#---------------#



AustinMap <- ggmap(get_map(location = c(lon = -97.78, lat = 30.28), zoom = 11)) 


SimAdoptersDensPlotName = sprintf("BAMEx_MapSimDens_%s.png", paste(CompareModelNumber, collapse="-"))

SimAdoptersDensPlot <- AustinMap +
#	geom_point(data = agents, aes(x = WGSlong, y = WGSlat), shape = 16, size = 0.6) + 
	geom_tile(data=SimDensMap100.m, aes(x = adjLong, y  = adjLat, z=z, fill=z, alpha=z)) +
	geom_contour(data=SimDensMap100.m, aes(x = adjLong, y  = adjLat, z=z)) + 
#	geom_point(data=EmpDensMap100.m, aes(x = adjLong, y  = adjLat, color=adjz, alpha=adjz), size = 1.5, shape = 16) +
 	scale_fill_gradient(low="green", high="red", name="Simulation\nAdoption\nDensity") +
  	coord_cartesian(xlim=LongRange, ylim=LatRange) +
  	guides(alpha=FALSE) + 
  	scale_x_continuous(name="Longitude") +
	scale_y_continuous(name="Latitude") +
	theme_bw()
ggsave(SimAdoptersDensPlotName, SimAdoptersDensPlot, path = "analytics/graphics/")





DiffAdoptersSTDDensPlotName = sprintf("BAMEx_MapSimDensDiff_%s.png", paste(CompareModelNumber, collapse="-"))

DiffAdoptersSTDDensPlot <- AustinMap +
#	geom_point(data = agents, aes(x = WGSlong, y = WGSlat), shape = 16, size = 0.6) + 
	geom_tile(data=SimDensMap100.m, aes(x = adjLong, y  = adjLat, z=STDDiffz, fill=STDDiffz, alpha=abs(STDDiffz))) +
	geom_contour(data=SimDensMap100.m, aes(x = adjLong, y  = adjLat, z=STDDiffz)) + 
#	geom_point(data=EmpDensMap100.m, aes(x = adjLong, y  = adjLat, color=adjz, alpha=adjz), size = 1.5, shape = 16) +
  	scale_fill_gradient2(low="blue",mid="grey", high="red", midpoint=0, name="Error:\nStd(Sim.) -\nStd(Empir.)") +
  	coord_cartesian(xlim=LongRange, ylim=LatRange) +
  	guides(alpha=FALSE) + 
  	scale_x_continuous(name="Longitude") +
	scale_y_continuous(name="Latitude") +
	theme_bw()
ggsave(DiffAdoptersSTDDensPlotName, DiffAdoptersSTDDensPlot, path = "analytics/graphics/")



q()


